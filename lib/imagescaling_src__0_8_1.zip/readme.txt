Image Scaling Library for Java
--------------------------------

The purpose of the library is to provide better image scaling options
than the Java runtime provides.

Copyright 2008 Morten Nobel-Joergensen

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation, either version 3 of the License, or
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

This library is is released under LGPL version 3.0. Read the license.txt
for more details.

